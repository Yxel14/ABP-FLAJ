/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.pruebas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.SwingUtilities;

@SuppressWarnings("serial")
public class Game extends JPanel {
    public Ball ball = new Ball(this);
    public Racquet racquet = new Racquet(this);
    public double speed = 0.5;
    public long startTime = System.currentTimeMillis(); 

    private int getScore() {
        long elapsedTime = System.currentTimeMillis() - startTime;
        return (int) (elapsedTime); // Divide by 1000 to convert milliseconds to seconds
    }

    public Game() {
        setFocusable(true);
        Sound.BACK.loop();

        // Configure timer to change speed every x seconds
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                changeSpeed(); 
            }
        }, 0, 20000); // Change speed every 20 seconds

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                racquet.keyPressed(e);
            }

            @Override
            public void keyReleased(KeyEvent e) {
                racquet.keyReleased(e);
            }
        });

        // Start game loop
        startGameLoop();
    }

    private void changeSpeed() {
        speed++; // Increment speed every time this method is called
    }

    private void move() {
        ball.move();
        racquet.move();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        ball.paint(g2d);
        racquet.paint(g2d);

        g2d.setColor(Color.GRAY);
        g2d.setFont(new Font("Verdana", Font.BOLD, 30));
        g2d.drawString(String.valueOf(getScore()), 10, 30);
    }

    public void gameOver() {
        Sound.BACK.stop();
        Sound.GAMEOVER.play();
        JOptionPane.showMessageDialog(this, "Your score is: " + getScore(), "Game Over", JOptionPane.YES_NO_OPTION);
        System.exit(ABORT);
    }

    public void startGameLoop() {
        // Start a timer to repeatedly call move() and repaint() at regular intervals
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                move();
                repaint();
            }
        }, 0, 10); // Call move() and repaint() every 10 milliseconds
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Mini Tennis");
            Game game = new Game();
            frame.add(game);
            frame.setSize(300, 400);
            frame.setVisible(true);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        });
    }
}