package com.mycompany.pruebas;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Videojogo extends JFrame implements ActionListener {

    private CardLayout cardLayout;
    private JPanel pagesPanel;
    private JRadioButton catalaRadioButton, castellaRadioButton;
    private JLabel label2, label3, label4;
    private JComboBox<String> nivelComboBox;
    private JRadioButton obstaculosSiRadioButton, obstaculosNoRadioButton;
    private JButton nextPage2Button, nextPage3Button, aceptarButton;
    private JTextField nombreUsuarioField; // Declarar el JTextField para el nombre de usuario
    private Game game; // Referencia al juego

    public Videojogo() {
        setTitle("Menú con Páginas");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardLayout = new CardLayout();
        pagesPanel = new JPanel(cardLayout);

        JPanel page1 = createPage1();
        JPanel page2 = createPage2();
        JPanel page3 = createPage3();
        JPanel page4 = createPage4();

        pagesPanel.add(page1, "page1");
        pagesPanel.add(page2, "page2");
        pagesPanel.add(page3, "page3");
        pagesPanel.add(page4, "page4");

        add(pagesPanel);

        setVisible(true);
    }

    private JPanel createPage1() {
        JPanel page = new JPanel();
        JLabel label1 = new JLabel("Selecciona Idioma:");
        catalaRadioButton = new JRadioButton("Català");
        castellaRadioButton = new JRadioButton("Castellà");
        page.add(label1);
        page.add(catalaRadioButton);
        page.add(castellaRadioButton);
        JButton nextPage1Button = new JButton("OK");
        nextPage1Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (catalaRadioButton.isSelected()) {
                    label2.setText("Introduce tu nombre:");
                    label3.setText("Selecciona el nivel de inicio:");
                    label4.setText("Selecciona tipo de obstáculos:");
                    nextPage2Button.setText("Siguiente");
                    nextPage3Button.setText("Siguiente");
                    aceptarButton.setText("Aceptar");
                }
                cardLayout.show(pagesPanel, "page2");
            }
        });
        page.add(nextPage1Button);
        return page;
    }

private JPanel createPage2() {
    JPanel page = new JPanel();
    label2 = new JLabel("Introduce tu nombre:");
    nombreUsuarioField = new JTextField(15);
    page.add(label2);
    page.add(nombreUsuarioField);
    nextPage2Button = new JButton("Siguiente");
    nextPage2Button.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            cardLayout.show(pagesPanel, "page3");
        }
    });
    page.add(nextPage2Button);
    return page;
}

    private JPanel createPage3() {
        JPanel page = new JPanel();
        label3 = new JLabel("Seleccionar el nivel de inicio:");
        nivelComboBox = new JComboBox<>(new String[]{"Fácil", "Medio", "Difícil"});
        page.add(label3);
        page.add(nivelComboBox);
        nextPage3Button = new JButton("Siguiente");
        nextPage3Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(pagesPanel, "page4");
            }
        });
        page.add(nextPage3Button);
        return page;
    }

    private JPanel createPage4() {
        JPanel page = new JPanel();
        label4 = new JLabel("Seleccionar tipo de obstáculos:");
        obstaculosSiRadioButton = new JRadioButton("Sí");
        obstaculosNoRadioButton = new JRadioButton("No");
        page.add(label4);
        page.add(obstaculosSiRadioButton);
        page.add(obstaculosNoRadioButton);
        aceptarButton = new JButton("Aceptar");
        aceptarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Ocultar el menú
                setVisible(false);
                // Iniciar el juego
                startGame();
            }
        });
        page.add(aceptarButton);
        return page;
    }

    private void startGame() {
        // Crear una nueva instancia de Game
        game = new Game();
        // Obtener el JFrame principal
        JFrame mainFrame = (JFrame) SwingUtilities.getWindowAncestor(pagesPanel);
        // Agregar el juego al JFrame principal
        mainFrame.getContentPane().removeAll();
        mainFrame.getContentPane().add(game);
        mainFrame.setSize(300, 400);
        mainFrame.setVisible(true);
        // Solicitar el enfoque en el juego para que las teclas funcionen
        game.requestFocusInWindow();
        // Iniciar el bucle del juego
        game.startGameLoop();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Videojogo menu = new Videojogo();
            menu.setVisible(true); 
        });
    }
}